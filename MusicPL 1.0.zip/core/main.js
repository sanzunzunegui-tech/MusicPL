const { exec } = require('child_process');
const path = require('path');

// Abre tu index.html en modo aplicación independiente usando Edge de Windows
const fileUrl = `file://${path.join(__dirname, 'index.html')}`;
exec(`start msedge --app="${fileUrl}"`, (err) => {
  if (err) {
    // Si por alguna razón falla Edge, lo tira en el navegador por defecto
    exec(`start ${fileUrl}`);
  }
  process.exit(); // Cierra el proceso de fondo para que quede limpio
});